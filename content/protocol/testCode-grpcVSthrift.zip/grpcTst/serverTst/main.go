package main

import (
	"context"
	"fmt"
	"net"
	"sync/atomic"

	"google.golang.org/grpc"
	"testcode.com/grpcTst/msgCommon"
)

func main() {
	lis, err := net.Listen("tcp", fmt.Sprintf(":%d", 2001))
	if err != nil {
		fmt.Println("tcp listen error:", err.Error())
		return
	}

	grpcServer := grpc.NewServer()                                              //// 定义grpc服务，根据实际可以传相关配置参数
	msgCommon.RegisterStudentServiceServer(grpcServer, new(StudentServiceImpl)) //// 注册服务

	grpcServer.Serve(lis) //// 开始处理。此处会卡住
}

type StudentServiceImpl struct {
	maxId int64
}

func (this *StudentServiceImpl) GetAllStudent(contextObj context.Context, req *msgCommon.VoidMsg) (*msgCommon.GetAllStudentResponse, error) {
	return &msgCommon.GetAllStudentResponse{
		StudentList: []*msgCommon.Student{
			&msgCommon.Student{
				Id:   1,
				Name: "student1",
				Sex:  msgCommon.Sex_Man,
			},
		},
	}, nil
}

func (this *StudentServiceImpl) AddStudent(contextObj context.Context, req *msgCommon.Student) (*msgCommon.AddStudentResponse, error) {
	newId := atomic.AddInt64(&this.maxId, 1)

	return &msgCommon.AddStudentResponse{
		Id: int32(newId),
	}, nil
}

func (this *StudentServiceImpl) Hello(contextObj context.Context, req *msgCommon.HelloInfo) (*msgCommon.VoidMsg, error) {
	//fmt.Println("Hello:", req.Name)
	return &msgCommon.VoidMsg{}, nil
}
