package main

import (
	"context"
	"fmt"
	"sync"
	"time"

	"google.golang.org/grpc"
	"testcode.com/grpcTst/msgCommon"
)

func main() {
	conn, err := grpc.Dial("127.0.0.1:2001", grpc.WithInsecure()) //// 连接到Server，并设置为不需要安全验证
	if err != nil {
		fmt.Println("error:", err.Error())
		return
	}
	defer conn.Close()

	// 通过连接获取一个TstServer的本地代理对象
	clientObj := msgCommon.NewStudentServiceClient(conn)

	waitObj := sync.WaitGroup{}
	waitObj.Add(1)
	go func() {
		startTime := time.Now()
		for i := 0; i < 100000; i++ {
			_, err := clientObj.AddStudent(context.Background(), &msgCommon.Student{
				Id:   int32(i),
				Name: fmt.Sprintf("stu%v", i),
				Sex:  msgCommon.Sex_Man,
			})
			if err != nil {
				fmt.Println("invoke error:", err.Error())
				continue
			} else {
				//fmt.Println("stuId:", responseObj.Id)
			}
		}
		endTime := time.Now()

		fmt.Println("内部总耗时:", endTime.Sub(startTime).Microseconds())
		fmt.Println("内部单次性能:", endTime.Sub(startTime).Microseconds()/100000)
		waitObj.Done()
	}()

	startTime := time.Now()
	for i := 0; i < 100000; i++ {
		_, err := clientObj.AddStudent(context.Background(), &msgCommon.Student{
			Id:   int32(i),
			Name: fmt.Sprintf("stu%v", i),
			Sex:  msgCommon.Sex_Man,
		})
		if err != nil {
			fmt.Println("invoke error:", err.Error())
			continue
		} else {
			//fmt.Println("stuId:", responseObj.Id)
		}
		/*
			clientObj.Hello(context.Background(), &msgCommon.HelloInfo{
				Name: fmt.Sprintf("name%v", i),
			})
		*/
	}
	endTime := time.Now()

	fmt.Println("总耗时:", endTime.Sub(startTime).Microseconds())
	fmt.Println("单次性能:", endTime.Sub(startTime).Microseconds()/100000)

	waitObj.Wait()
}
