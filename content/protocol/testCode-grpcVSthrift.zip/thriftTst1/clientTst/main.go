package main

import (
	"context"
	"fmt"
	"log"
	"sync"
	"time"

	"github.com/apache/thrift/lib/go/thrift"
	"testcode.com/thriftTst1/msgCommon"
)

func main2() {
	transport, err := thrift.NewTSocket("localhost:9090")
	if err != nil {
		log.Fatalf("%s\n", err.Error())
	}
	protocolFactory := thrift.NewTBinaryProtocolFactoryDefault()
	client := msgCommon.NewStudentServiceClientFactory(transport, protocolFactory)

	transport.Open()
	defer transport.Close()

	sum, err := client.Hello(context.Background(), "你好")
	if err != nil {
		log.Fatalf("%s\n", err.Error())
	}

	fmt.Printf("%d", sum)
}

func main() {
	transport, err := thrift.NewTSocket("localhost:9090")
	if err != nil {
		log.Fatalf("%s\n", err.Error())
	}

	protocol := thrift.NewTBinaryProtocol(transport, true, true)

	mp1 := thrift.NewTMultiplexedProtocol(protocol, "StudentService")
	studentService := msgCommon.NewStudentServiceClientProtocol(transport, protocol, mp1)

	//studentService := msgCommon.NewStudentServiceClientFactory(transport, thrift.NewTBinaryProtocolFactory(true, true))

	//mp2 := thrift.NewTMultiplexedProtocol(protocol, "AccountService")
	//accountService := msgCommon.NewAccountServiceClientProtocol(transport, protocol, mp2)

	err = transport.Open()
	if err != nil {
		fmt.Println("open connection errror:", err.Error())
		return
	}
	defer transport.Close()

	waitObj := sync.WaitGroup{}
	waitObj.Add(1)

	go func() {
		transport, err := thrift.NewTSocket("localhost:9090")
		if err != nil {
			log.Fatalf("%s\n", err.Error())
		}

		protocol := thrift.NewTBinaryProtocol(transport, true, true)

		mp1 := thrift.NewTMultiplexedProtocol(protocol, "StudentService")
		studentService := msgCommon.NewStudentServiceClientProtocol(transport, protocol, mp1)
		err = transport.Open()
		if err != nil {
			fmt.Println("open connection errror:", err.Error())
			return
		}
		defer transport.Close()

		startTime := time.Now()
		for i := 0; i < 100000; i++ {
			name := fmt.Sprintf("stu%v", i)
			_, err := studentService.AddStudent(context.Background(), &msgCommon.Student{
				ID:   int32(i),
				Name: &name,
				Sex:  msgCommon.Sex_Man,
			})
			if err != nil {
				fmt.Println("invoke error:", err.Error())
				continue
			} else {
				//fmt.Println("stuId:", responseObj.Id)
			}
		}
		endTime := time.Now()

		fmt.Println("内部总耗时:", endTime.Sub(startTime).Microseconds())
		fmt.Println("内部单次性能:", endTime.Sub(startTime).Microseconds()/100000)
		waitObj.Done()
	}()

	startTime := time.Now()
	for i := 0; i < 100000; i++ {
		name := fmt.Sprintf("stu%v", i)
		_, err := studentService.AddStudent(context.Background(), &msgCommon.Student{
			ID:   int32(i),
			Name: &name,
			Sex:  msgCommon.Sex_Man,
		})
		if err != nil {
			fmt.Println("invoke error:", err.Error())
			continue
		} else {
			//fmt.Println("stuId:", responseObj.Id)
		}
		/*
			clientObj.Hello(context.Background(), &msgCommon.HelloInfo{
				Name: fmt.Sprintf("name%v", i),
			})
		*/
	}
	endTime := time.Now()

	fmt.Println("总耗时:", endTime.Sub(startTime).Microseconds())
	fmt.Println("单次性能:", endTime.Sub(startTime).Microseconds()/100000)

	waitObj.Wait()
	//fmt.Printf("%s", sum)
}
