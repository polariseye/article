namespace go msgCommon

enum Sex{
    Man = 1,
    Woman =2,
}

struct Student{
    1:i32 Id,
    2:optional string Name,
    3:Sex Sex,
}

service StudentService{
    list<Student> GetAllStudent(),

    i32 AddStudent(1:Student student),

    string Hello(1:string name),

    oneway void AsyncHello(1:string name)
}