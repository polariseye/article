namespace go msgCommon

struct TstInfo {
    1:binary Data
}

service AccountService{
    string Hello(1:string name),

    oneway void AsyncHello(1:string name)
}