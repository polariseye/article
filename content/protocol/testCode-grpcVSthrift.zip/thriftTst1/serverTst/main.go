package main

import (
	"context"
	"fmt"
	"log"
	"sync/atomic"
	"time"

	"github.com/apache/thrift/lib/go/thrift"
	"testcode.com/thriftTst1/msgCommon"
)

// StudentService asd
type StudentService struct {
	maxId int64
}

// GetAllStudent asd
func (handler *StudentService) GetAllStudent(ctx context.Context) (result []*msgCommon.Student, err error) {
	name := "student1"
	result = []*msgCommon.Student{
		&msgCommon.Student{
			ID:   1,
			Name: &name,
			Sex:  msgCommon.Sex_Man,
		},
	}

	err = fmt.Errorf("hello world")
	return
}

func (this *StudentService) AddStudent(ctx context.Context, student *msgCommon.Student) (r int32, err error) {
	newId := atomic.AddInt64(&this.maxId, 1)
	return int32(newId), nil
}
func (this *StudentService) Hello(ctx context.Context, name string) (r string, err error) {
	fmt.Println("开始调用了")
	time.Sleep(5 * time.Second)
	fmt.Println("调用结束了")
	return "这只是一个简单测试:" + name, nil
}
func (this *StudentService) AsyncHello(ctx context.Context, name string) (err error) {
	fmt.Println("调用了哦~~~~" + name)
	return nil
}

type AccountService struct {
}

func (this *AccountService) Hello(ctx context.Context, name string) (r string, err error) {
	return "这只是一个简单测试:" + name, nil
}
func (this *AccountService) AsyncHello(ctx context.Context, name string) (err error) {
	fmt.Println("调用了哦~~~~" + name)
	return nil
}

func main() {
	processor := thrift.NewTMultiplexedProcessor()
	processor.RegisterProcessor("StudentService", msgCommon.NewStudentServiceProcessor(&StudentService{}))
	processor.RegisterProcessor("AccountService", msgCommon.NewAccountServiceProcessor(&AccountService{}))

	transport, err := thrift.NewTServerSocket("localhost:9090")
	if err != nil {
		log.Fatalf("%s\n", err.Error())
		return
	}

	server := thrift.NewTSimpleServer2(processor, transport)
	server.Serve()
}
